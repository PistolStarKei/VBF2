var class_kalagaan_1_1_vert_exmotion_collider_1_1_collision_zone =
[
    [ "collisionVector", "class_kalagaan_1_1_vert_exmotion_collider_1_1_collision_zone.html#a1d9514a2a0ec62b4cc2e7d8c6df278be", null ],
    [ "hits", "class_kalagaan_1_1_vert_exmotion_collider_1_1_collision_zone.html#adc970ca84cb5afc4b9aac12e4175408f", null ],
    [ "positionOffset", "class_kalagaan_1_1_vert_exmotion_collider_1_1_collision_zone.html#afa4fe43a217212b3145b5562b2ccfc77", null ],
    [ "radius", "class_kalagaan_1_1_vert_exmotion_collider_1_1_collision_zone.html#a1a35fae8413c0f252ab05c396b303019", null ]
];