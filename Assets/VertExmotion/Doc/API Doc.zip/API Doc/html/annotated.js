var annotated =
[
    [ "Kalagaan", "namespace_kalagaan.html", "namespace_kalagaan" ]
];