var class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone =
[
    [ "collisionVector", "class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a2c2da605bdc8cc51ea0f7690a052bb1e", null ],
    [ "hits", "class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a962b2a1aaa690dcbd99b5c062b7b964d", null ],
    [ "positionOffset", "class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a45ce24a8ab3f0d5661be87b2bc4cd50f", null ],
    [ "radius", "class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a3d69efb54838d8d1e63175ab24e515f6", null ]
];