var searchData=
[
  ['parameters',['Parameters',['../class_kalagaan_1_1_p_i_d_1_1_parameters.html#a55c0723a664455c375fce6ee0ed731e0',1,'Kalagaan.PID.Parameters.Parameters()'],['../class_kalagaan_1_1_p_i_d_1_1_parameters.html#aad7e5939be0364ba8b4e16d0da6544bd',1,'Kalagaan.PID.Parameters.Parameters(Parameters p)']]],
  ['pid',['PID',['../class_kalagaan_1_1_p_i_d.html#af13a4455e64a4539d5eb7db8389ffda5',1,'Kalagaan.PID.PID()'],['../class_kalagaan_1_1_p_i_d.html#a3db5076d0850724bb46ccf691ef9bfb2',1,'Kalagaan.PID.PID(float kp, float ki, float kd)']]]
];
