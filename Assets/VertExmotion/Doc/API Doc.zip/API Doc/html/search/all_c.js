var searchData=
[
  ['none',['NONE',['../class_kalagaan_1_1_vert_exmotion_editor.html#a947139bf576ec2ec97e42b476f7afe3eab50339a10e1de285ac99d4c3990b8693',1,'Kalagaan.VertExmotionEditor.NONE()'],['../class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7ab50339a10e1de285ac99d4c3990b8693',1,'Kalagaan.VertExmotionSensorEditor.NONE()']]]
];
