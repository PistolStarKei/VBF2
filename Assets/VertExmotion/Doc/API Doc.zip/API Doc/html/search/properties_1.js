var searchData=
[
  ['timescale',['timeScale',['../class_kalagaan_1_1_vert_exmotion_sensor_base.html#a547fc8266acff933474b5e71f301ca95',1,'Kalagaan.VertExmotionSensorBase.timeScale()'],['../class_kalagaan_1_1_p_i_d___v3.html#a3117e544eaf0feb6b58a48bf2874145c',1,'Kalagaan.PID_V3.timeScale()']]]
];
