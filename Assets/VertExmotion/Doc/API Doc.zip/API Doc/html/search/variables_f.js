var searchData=
[
  ['torque',['torque',['../class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter.html#a7a45fdc1e7ebdb2b9800793260a05105',1,'Kalagaan::VertExmotionSensorBase::Parameter']]],
  ['translation',['translation',['../class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter.html#a88823d1a96b37f66bb289c273cf8a51a',1,'Kalagaan::VertExmotionSensorBase::Parameter']]]
];
