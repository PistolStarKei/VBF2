var searchData=
[
  ['collisionzone',['CollisionZone',['../class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html',1,'Kalagaan::VertExmotionColliderBase']]]
];
