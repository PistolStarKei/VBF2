var searchData=
[
  ['classname',['className',['../class_kalagaan_1_1_vert_exmotion_base.html#ae862bdc009506ce422fe85555e736f3d',1,'Kalagaan.VertExmotionBase.className()'],['../class_kalagaan_1_1_vert_exmotion_collider_base.html#a4caab89b6997030e5a05dc822d4cffeb',1,'Kalagaan.VertExmotionColliderBase.className()'],['../class_kalagaan_1_1_vert_exmotion_sensor_base.html#a6fc7dfd5d794f94972d99de7442103e8',1,'Kalagaan.VertExmotionSensorBase.className()']]],
  ['collisionvector',['collisionVector',['../class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a2c2da605bdc8cc51ea0f7690a052bb1e',1,'Kalagaan::VertExmotionColliderBase::CollisionZone']]]
];
