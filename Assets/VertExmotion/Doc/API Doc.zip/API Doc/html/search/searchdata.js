var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvw",
  1: "cfptv",
  2: "k",
  3: "abcdfgioprstu",
  4: "abcdfghiklmoprstuvw",
  5: "e",
  6: "cfimnps",
  7: "rt",
  8: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Pages"
};

