var searchData=
[
  ['positionoffset',['positionOffset',['../class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html#a45ce24a8ab3f0d5661be87b2bc4cd50f',1,'Kalagaan::VertExmotionColliderBase::CollisionZone']]]
];
