var searchData=
[
  ['version',['version',['../class_kalagaan_1_1_vert_exmotion_base.html#a6077497d44526d5e1a6af02c0b18f872',1,'Kalagaan.VertExmotionBase.version()'],['../class_kalagaan_1_1_vert_exmotion_base_1_1_parameters.html#a7cb3aabf33491032a419eccf2af5c712',1,'Kalagaan.VertExmotionBase.Parameters.version()']]]
];
