var searchData=
[
  ['kalagaan',['Kalagaan',['../namespace_kalagaan.html',1,'']]]
];
