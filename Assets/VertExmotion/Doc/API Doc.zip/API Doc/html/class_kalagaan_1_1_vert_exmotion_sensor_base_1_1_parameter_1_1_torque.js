var class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque =
[
    [ "amplitude", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html#a14d9e4ce525a6c9ca21d5e561d4e5bb6", null ],
    [ "bouncing", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html#a04c94819321c13ea40596192e78f0626", null ],
    [ "damping", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html#a3a9191be75a0a729cdfc51734174a072", null ],
    [ "max", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html#a454e901076290d14d92f0af37d614d51", null ],
    [ "smooth", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html#af24fb74130539c19d20b521f55db8685", null ]
];