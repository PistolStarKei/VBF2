var class_vert_exmotion_share =
[
    [ "m_copyDeltaPosition", "class_vert_exmotion_share.html#ac0626f41803a023a27a8bb399af342c6", null ],
    [ "m_copyRotation", "class_vert_exmotion_share.html#a3df9dc47f00ee3dd15e345314ef2a6e7", null ],
    [ "m_reference", "class_vert_exmotion_share.html#a4b39e44c56023a9fedc839b9e8c6de89", null ]
];