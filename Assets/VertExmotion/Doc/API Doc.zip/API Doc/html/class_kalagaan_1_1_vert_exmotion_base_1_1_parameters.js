var class_kalagaan_1_1_vert_exmotion_base_1_1_parameters =
[
    [ "usePaintDataFromMeshColors", "class_kalagaan_1_1_vert_exmotion_base_1_1_parameters.html#a47abc4aaa15f070ae0732e329c0a0438", null ],
    [ "version", "class_kalagaan_1_1_vert_exmotion_base_1_1_parameters.html#a7cb3aabf33491032a419eccf2af5c712", null ]
];