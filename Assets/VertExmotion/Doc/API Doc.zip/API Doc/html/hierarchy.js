var hierarchy =
[
    [ "Kalagaan.VertExmotionColliderBase.CollisionZone", "class_kalagaan_1_1_vert_exmotion_collider_base_1_1_collision_zone.html", null ],
    [ "Editor", null, [
      [ "Kalagaan.VertExmotionEditor", "class_kalagaan_1_1_vert_exmotion_editor.html", null ],
      [ "Kalagaan.VertExmotionSensorEditor", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html", null ]
    ] ],
    [ "Kalagaan.VertExmotionSensorBase.Parameter.FX", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_f_x.html", null ],
    [ "MonoBehaviour", null, [
      [ "Kalagaan.VertExmotionBase", "class_kalagaan_1_1_vert_exmotion_base.html", [
        [ "Kalagaan.VertExmotion", "class_kalagaan_1_1_vert_exmotion.html", null ]
      ] ],
      [ "Kalagaan.VertExmotionColliderBase", "class_kalagaan_1_1_vert_exmotion_collider_base.html", [
        [ "Kalagaan.VertExmotionCollider", "class_kalagaan_1_1_vert_exmotion_collider.html", null ]
      ] ],
      [ "Kalagaan.VertExmotionSensorBase", "class_kalagaan_1_1_vert_exmotion_sensor_base.html", [
        [ "Kalagaan.VertExmotionSensor", "class_kalagaan_1_1_vert_exmotion_sensor.html", null ]
      ] ],
      [ "VertExmotionShare", "class_vert_exmotion_share.html", null ]
    ] ],
    [ "Kalagaan.VertExmotionSensorBase.Parameter", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter.html", null ],
    [ "Kalagaan.VertExmotionBase.Parameters", "class_kalagaan_1_1_vert_exmotion_base_1_1_parameters.html", null ],
    [ "Kalagaan.PID.Parameters", "class_kalagaan_1_1_p_i_d_1_1_parameters.html", null ],
    [ "Kalagaan.PID", "class_kalagaan_1_1_p_i_d.html", null ],
    [ "Kalagaan.PID_V3", "class_kalagaan_1_1_p_i_d___v3.html", null ],
    [ "Kalagaan.VertExmotionSensorBase.Parameter.Torque", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_torque.html", null ],
    [ "Kalagaan.VertExmotionSensorBase.Parameter.Translation", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html", null ]
];