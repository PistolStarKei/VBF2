var class_vert_exmotion_sensor_1_1_parameter_1_1_translation =
[
    [ "amplitudeMultiplier", "class_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a6633a85ba2a4a1494e8dd5bde0c883e7", null ],
    [ "innerMaxDistance", "class_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a1c9dbab6b6418aaa639822cd00990880", null ],
    [ "offset", "class_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a8dfdf8af9e91fe06b28806f5ed087688", null ],
    [ "outerMaxDistance", "class_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#af4cf582fc20ea7bf81b58538bf2c438a", null ]
];