var class_vert_exmotion_collider_1_1_collision_zone =
[
    [ "collisionVector", "class_vert_exmotion_collider_1_1_collision_zone.html#a477ce59753cdd26b91792fe6d974f658", null ],
    [ "hits", "class_vert_exmotion_collider_1_1_collision_zone.html#a1a96cdf6e160b5673d9eeb3037924e9d", null ],
    [ "positionOffset", "class_vert_exmotion_collider_1_1_collision_zone.html#a528ff8bdf27a6c440745a968c8093647", null ],
    [ "radius", "class_vert_exmotion_collider_1_1_collision_zone.html#a9decf9dbfccedd84379e25bb604e4515", null ]
];