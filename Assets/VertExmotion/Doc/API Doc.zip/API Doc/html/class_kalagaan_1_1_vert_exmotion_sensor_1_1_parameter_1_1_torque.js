var class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque =
[
    [ "amplitude", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a5e9cb390f0e755a908da4c8df158be0c", null ],
    [ "bouncing", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a4bfee55d8bc6dfcaccd526a205e7863e", null ],
    [ "damping", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a3f082f682bd2172e74a0290a5e33fe19", null ],
    [ "max", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#afbb72b554a5549ec70e5d6d5508c5df9", null ],
    [ "smooth", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a3dd2fcbc5f6368a51769d8a3e062b39d", null ]
];