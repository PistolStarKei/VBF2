var class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation =
[
    [ "amplitudeMultiplier", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a5bf9d872878c0c64bf8b5f4db7b25061", null ],
    [ "gravityInOut", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a854693e54d8b4b9c6334b1bb1c02ff65", null ],
    [ "innerMaxDistance", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a0ce8bb5d87a10869ee661e0a326c1cca", null ],
    [ "localOffset", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a9d1a28a61fa37778da46bd2988e30afc", null ],
    [ "outerMaxDistance", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a163f7a1af6d9037c786623077abb067e", null ],
    [ "worldOffset", "class_kalagaan_1_1_vert_exmotion_sensor_base_1_1_parameter_1_1_translation.html#a2509da5dfc619f2f6a95fe1e30cf840c", null ]
];