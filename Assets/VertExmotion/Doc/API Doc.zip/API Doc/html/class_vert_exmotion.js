var class_vert_exmotion =
[
    [ "ApplyMotionData", "class_vert_exmotion.html#af9d3fc395aeb4ef7bd21d6016b26b723", null ],
    [ "DisableMotion", "class_vert_exmotion.html#aa38b97dfda1adfa1c52d78c64481fb81", null ],
    [ "InitMaterial", "class_vert_exmotion.html#a13456a90901f1673d17777db14d65a03", null ],
    [ "InitMesh", "class_vert_exmotion.html#a18b6bae32dce3a34bf0dc04c911f2448", null ],
    [ "InitVertices", "class_vert_exmotion.html#a76c8968013437df47172d2f9b4bf6638", null ],
    [ "m_initialShader", "class_vert_exmotion.html#af5a5a99f11cec13151f94f3417d5eaaa", null ],
    [ "m_mesh", "class_vert_exmotion.html#af128ef5c4541ad1e3b5ed609d6c81f56", null ],
    [ "m_meshCopy", "class_vert_exmotion.html#adc68be5f01eeedf02dd3a0886434c8c9", null ],
    [ "m_sharedMaterial", "class_vert_exmotion.html#a42682c0d0980cbceb619217832aa1c1a", null ],
    [ "m_sharedMesh", "class_vert_exmotion.html#a74a95311b4d78ea6a84a280bc424e074", null ],
    [ "m_vertexColors", "class_vert_exmotion.html#a36c1f0f7cebf2e792616f73324937d68", null ],
    [ "m_VertExmotionSensors", "class_vert_exmotion.html#a5df2cde23f825a77a404b7e21b604d92", null ],
    [ "m_weightPackVersion", "class_vert_exmotion.html#a49d6683e5c3972779ae1c00ea4c6abd6", null ]
];