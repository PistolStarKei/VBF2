var namespaces =
[
    [ "Kalagaan", "namespace_kalagaan.html", null ]
];