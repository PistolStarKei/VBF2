var class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation =
[
    [ "amplitudeMultiplier", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#aef57890b03a38794a486596b92d3b129", null ],
    [ "gravityInOut", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a7f54b8bafc931ffd74cddb0529bd141e", null ],
    [ "innerMaxDistance", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a07d4c8892aa25cd50628a3e61811c255", null ],
    [ "localOffset", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#aa534482f9010ecf496852b97723f1822", null ],
    [ "outerMaxDistance", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a3f298d0d2815a4cd759022974ccdf88a", null ],
    [ "worldOffset", "class_kalagaan_1_1_vert_exmotion_sensor_1_1_parameter_1_1_translation.html#a3740bdb30d2119ae2ba65d00b9fa3d68", null ]
];