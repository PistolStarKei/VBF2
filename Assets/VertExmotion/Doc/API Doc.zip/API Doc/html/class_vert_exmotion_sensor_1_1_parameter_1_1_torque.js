var class_vert_exmotion_sensor_1_1_parameter_1_1_torque =
[
    [ "amplitude", "class_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#ad561ee5273cbf6380a99115ff6de6d4e", null ],
    [ "max", "class_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a22f520002905b23ffbc6050df19fd251", null ],
    [ "smooth", "class_vert_exmotion_sensor_1_1_parameter_1_1_torque.html#a3fb600be3c6869e17493dbcbdf1ca640", null ]
];