var class_kalagaan_1_1_vert_exmotion_sensor_editor =
[
    [ "eSettingsMode", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7", [
      [ "NONE", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7ab50339a10e1de285ac99d4c3990b8693", null ],
      [ "SENSORS", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7a3f9d1c3652820e6c9716f628c6f0b5af", null ],
      [ "FX", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7ab8b5089c70ae62534970e2d8aa67e96d", null ],
      [ "COLLIDERS", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a5559774179655f67e0d5bd4cebfa55b7adffa23e89f914b343e7811b01a8f756c", null ]
    ] ],
    [ "OnDisable", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#ab23f66f4dcaea252d927b3bbc8b48e62", null ],
    [ "OnEnable", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a1c8617cac6609cc4296b389316068784", null ],
    [ "OnInspectorGUI", "class_kalagaan_1_1_vert_exmotion_sensor_editor.html#a33dc02edd4df380ff0d391de8c324d3f", null ]
];